package ru.selemilka.webselemilka

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class WebSelemilkaApplicationTests {

	@Test
	fun contextLoads() {
	}

}
